import "reflect-metadata";
import { runServer } from "./server";

runServer()